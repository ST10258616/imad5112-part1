package com.kyle.comvarsitycollegedurbannorthst10258616

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun performOperation(view: View) {
        val number1EditText = findViewById<EditText>(R.id.num1)
        val number2EditText = findViewById<EditText>(R.id.num2)
        val ans = findViewById<TextView>(R.id.ans)

        val number1 = number1EditText.text.toString().toDouble()
        val number2 = number2EditText.text.toString().toDouble()

        val result = when (view.id) {
            R.id.btnAdd -> number1 + number2
            R.id.btnSub -> number1 - number2
            R.id.btnMult -> number1 * number2
            R.id.btnDiv -> number1 / number2
            else -> 0.0
        }

       ans.text = formatResult(result as Double)
    }

    private fun formatResult(result: Double): String {
        return if (result.isWhole()) {
            result.toLong().toString()
    } else {
        result.toString()
    }
}
    fun Double.isWhole() = this % 1 == 0.0 }

